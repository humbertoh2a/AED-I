#include <stdio.h>
#include "Stack.h"

int main()
{
  int n;
  scanf("%d", &n);

  Stack *s = create_stack();

  if (n == 0)
  {
    printf("0\n");
    free_stack(&s);
    return 0;
  }

  while (n > 0)
  {
    push(s, n % 2);
    n /= 2;
  }

  while (!is_empty(s))
  {
    int bit;
    pop(s, &bit);
    printf("%d", bit);
  }
  printf("\n");

  free_stack(&s);
  return 0;
}
